# py3fdfs-pypi.org
FastDFS python客户端，修复 pypi.org提供的 py3Fdfs-2.2.0包的bug



# 说明

作者在使用 [pypi.org](https://pypi.org/project/py3Fdfs/#modal-close)提供的 FastDFS客户端：py3Fdfs-2.2.0.tar.gz时发现一些问题，而苦于 2.2.0已经是最新版本，无奈只能自己动手修复问题

**修复的问题如下：**

1. 下载文件时偶尔报错 **socket timeout**，随即下载失败



实测本 FastDFS客户端支持 6.06版本的 FastDFS

后续有新的修改再同步到本项目..

其他的一些说明见原项目 README-old.md

